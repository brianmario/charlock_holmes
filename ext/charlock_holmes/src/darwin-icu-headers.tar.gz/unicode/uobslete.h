#ifndef UOBSLETE_H
#define UOBSLETE_H
#ifdef U_HIDE_OBSOLETE_API
#    if U_DISABLE_RENAMING
#    else
#    endif
#endif
#endif
